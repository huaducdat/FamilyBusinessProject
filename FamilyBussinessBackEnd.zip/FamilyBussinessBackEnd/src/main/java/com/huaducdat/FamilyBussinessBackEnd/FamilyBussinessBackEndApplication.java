package com.huaducdat.FamilyBussinessBackEnd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FamilyBussinessBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(FamilyBussinessBackEndApplication.class, args);
	}

}
