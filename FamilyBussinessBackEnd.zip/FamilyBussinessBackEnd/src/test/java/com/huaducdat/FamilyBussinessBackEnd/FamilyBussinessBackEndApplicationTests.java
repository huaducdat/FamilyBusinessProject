package com.huaducdat.FamilyBussinessBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FamilyBussinessBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
